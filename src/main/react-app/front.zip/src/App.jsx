import MainSearchPage from "./components/mainSearchPage"
import Search from "./components/Search"
function App() {

  return (
    <>
      <Search />
    </>
  )
}

export default App
